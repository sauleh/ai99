﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using AG1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestCommon;

namespace AG1.Tests
{
    [DeploymentItem("TestData", "A10_TestData")]
    [TestClass()]
    public class GradedTests
    {
        [TestMethod(), Timeout(1000)]
        public void SolveTest_Q1PhiX174GenomeErrorFree()
        {
            Assert.Inconclusive("AG1.Q1 Not Solved");
            RunTest(new Q1PhiX174GenomeErrorFree("TD1"));
        }

        [TestMethod(), Timeout(1000)]
        public void SolveTest_Q2PhiX174GenomeWithError()
        {
            Assert.Inconclusive("AG1.Q2 Not Solved");
            RunTest(new Q2PhiX174GenomeWithError("TD2"));
        }

        public static void RunTest(Processor p)
        {
            TestTools.RunLocalTest("AG1", p.Process, p.TestDataName, p.Verifier,
                VerifyResultWithoutOrder: p.VerifyResultWithoutOrder,
                excludedTestCases: p.ExcludedTestCases);
        }
    }
}