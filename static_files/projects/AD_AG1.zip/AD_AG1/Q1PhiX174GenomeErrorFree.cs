﻿using Microsoft.SolverFoundation.Solvers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using TestCommon;

namespace AG1
{
    public class Q1PhiX174GenomeErrorFree : Processor
    {
        public Q1PhiX174GenomeErrorFree(string testDataName) : base(testDataName)
        {
        }

        public override string Process(string inStr) =>
            TestTools.Process(inStr, (Func<string[], string>)Solve);


        public virtual string Solve(string[] genomeRead)
        {
            throw new NotImplementedException();
        }
    }
}
